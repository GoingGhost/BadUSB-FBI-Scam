Place all files into the USB.

Click on the visibility.bat to hide the files.

Click Virus to start payload.